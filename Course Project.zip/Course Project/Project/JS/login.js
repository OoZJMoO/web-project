function login() {
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;
  
  // TODO: Perform login validation
  
  // Example validation: Check if username is "admin" and password is "password"
  if (username === "admin" && password === "password") {
    // Redirect to home.html or products.html on successful login
    // Example redirect to home.html
    window.location.href = "home.html";
  } else {
    alert("Invalid username or password. Please try again.");
  }
}
